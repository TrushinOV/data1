package converters;

import com.qoppa.office.ExcelConvertOptions;
import com.qoppa.office.ExcelDocument;
import com.qoppa.office.WordDocument;

public class QoppaConverters {

    public static void main (String [] args)
    {
        try
        {
            // Load the document
            ExcelDocument ed = new ExcelDocument("01.xlsx", new ExcelConvertOptions());

            // Save the document as a PDF file
            ed.saveAsPDF("qoppa-xlsx-output.pdf");
        }
        catch (Throwable t)
        {
            t.printStackTrace();
        }

		try
    {
        // Load the document
        WordDocument wd = new WordDocument ("Zayavlenie_Anketa_2.docx");

        // Save the document as a PDF file
        wd.saveAsPDF("qoppa-docx-output.pdf");
    }
		catch (Throwable t)
    {
        t.printStackTrace();
    }
}

}
